<?php
    system("javac randomize.java"); 
    system("java randomize", $output);
    system("javac FCFS.java"); 
    system("java FCFS", $output);
    echo $output;
?> 