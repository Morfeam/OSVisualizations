<?php

    if($_POST['AlgoID'] == 1) {
        // CPU Schedule Input
        $processLength = rand(2,7);
        $procID = 1;
        $myfile = fopen("pracInput.txt", "w") or die("Unable to open file!");
    
        for($i = 0; $i < $processLength; $i++){
            $arriv = rand(0, 5);
            $burst = rand(1,10);
            $prio = rand(1, $processLength);
    
            fwrite($myfile, $procID);
            fwrite($myfile, ",");
            fwrite($myfile, $arriv);
            fwrite($myfile, ",");
            fwrite($myfile, $burst);
            fwrite($myfile, ",");
            fwrite($myfile, $prio);
            if($procID != $processLength)
                fwrite($myfile, "\n");
    
            $procID++;
        }

        header("Location: ../1-cpu/index.html");

    } else if($_POST['AlgoID'] == 2) {
        // Disk Schedule Input
        $diskStops = rand(5,10);
        $head = rand(0,199);



        header("Location: ../2-disk/index.html");

    } else if($_POST['AlgoID'] == 3) {
        // Page Replacement Input
        $frames = rand(2,5);


        
        
        header("Location: ../3-page/index.html");

    } else if($_POST['AlgoID'] == 4) {
        // Memory/File Allocation Input
        $slots = rand(3,5);
        $slotID = 1;

        for($i = 0; $i < $slots; $i++){







        }

        header("Location: ../4-memory/index.html");
    }

?>
