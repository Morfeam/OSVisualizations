In the command line enter "python mallocation.py" followed by the allocation method

ex.
python mallocation.py first_fit
python mallocation.py best_fit
python mallocation.py worst_fit