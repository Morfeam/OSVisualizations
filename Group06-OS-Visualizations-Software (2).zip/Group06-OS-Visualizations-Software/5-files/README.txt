In the command line enter "python fallocation.py" followed by the file allocation method

ex.
python fallocation.py contiguous
python fallocation.py linked_list
python fallocation.py indexed